#!/bin/bash

rm a.out parrot.so tiger.so
clear
