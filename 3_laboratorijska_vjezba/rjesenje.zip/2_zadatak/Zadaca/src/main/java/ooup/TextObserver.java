package ooup;

import ooup.TextEditorModel.Location;

public interface TextObserver {
    void updateText();
}
