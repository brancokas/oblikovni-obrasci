#!/bin/bash

rm a.out parrot.so tiger.so
echo "Obrisane exec datoteke."
