package ooup;

public interface DocumentModelListener {
    void documentChange();
}
